package com.shahnawaz.bikayidemo.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.gson.Gson;
import com.shahnawaz.bikayidemo.R;
import com.shahnawaz.bikayidemo.adapter.PrizesAdapter;
import com.shahnawaz.bikayidemo.core.GetDataContract;
import com.shahnawaz.bikayidemo.core.Presenter;
import com.shahnawaz.bikayidemo.model.Laureate;
import com.shahnawaz.bikayidemo.model.Prize;

import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity implements GetDataContract.View {

    private Presenter mPresenter;
    RecyclerView recyclerView;
    LinearLayoutManager linearLayoutManager;
    PrizesAdapter countryAdapter;

    Spinner spinnerCategory, spinnerYear;
    String[] course ={"Select a course","Android","Php","Mysql","Java","Angular","Python"};
    Button btnSearch;

    String category="";
    String year="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinnerCategory = (Spinner)findViewById(R.id.spinnerCategory);
        spinnerYear = (Spinner)findViewById(R.id.spinnerYear);
        btnSearch = (Button) findViewById(R.id.btnSearch);

        mPresenter = new Presenter(this);
        mPresenter.getDataFromURL(getApplicationContext(), "");
        recyclerView = (RecyclerView)findViewById(R.id.recycler);
        linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchData();
            }
        });

    }

    private void searchData()
    {
        System.out.println(year+category);
        mPresenter.searchFromList(getApplicationContext(),year, category);

    }

    @Override
    public void onGetDataSuccess(String message, List<Prize> allCountriesData) {
        /*countryAdapter = new PrizesAdapter(getApplicationContext(), allCountriesData);
        recyclerView.setAdapter(countryAdapter);*/
    }

    @Override
    public void onGetDataFailure(String message) {
        Log.d("Status",message);
    }

    @Override
    public void onGetDataSpinnerCategory(Set<String> list) {

        String[] arrayCategory = new String[list.size()];
        list.toArray(arrayCategory);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,R.layout.support_simple_spinner_dropdown_item,arrayCategory);

        adapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(adapter);

        spinnerCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(parent.getSelectedItem() == "Select a course"){

                }else{
                    category=parent.getItemAtPosition(position).toString();
                    //Toast.makeText(MainActivity.this, "Selected item is "+parent.getItemAtPosition(position).toString(), Toast.LENGTH_SHORT).show();

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    public void onGetDataSpinnerYear(List listYear) {
        System.out.println("listYear "+listYear);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,R.layout.support_simple_spinner_dropdown_item,listYear);

        adapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        spinnerYear.setAdapter(adapter);

        spinnerYear.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(parent.getSelectedItem() == "Select a course"){

                }else{
                    year=parent.getItemAtPosition(position).toString();
                    //Toast.makeText(MainActivity.this, "Selected item is "+parent.getItemAtPosition(position).toString(), Toast.LENGTH_SHORT).show();

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    public void onGetSearchedData(String message, List<Laureate> winners) {
        System.out.println(new Gson().toJson(winners));
        countryAdapter = new PrizesAdapter(getApplicationContext(), winners);
        recyclerView.setAdapter(countryAdapter);
    }

}
