package com.shahnawaz.bikayidemo.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.shahnawaz.bikayidemo.R;
import com.shahnawaz.bikayidemo.model.Laureate;

import java.util.ArrayList;
import java.util.List;


public class PrizesAdapter extends RecyclerView.Adapter<PrizesAdapter.MyViewHolder> {
    private Context context;
    private List<Laureate> list = new ArrayList<>();
    public PrizesAdapter(Context context, List<Laureate> list){
        this.context = context;
        this.list = list;
    }
    @Override
    public PrizesAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_item,parent,false);
        MyViewHolder myViewHolder = new MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(PrizesAdapter.MyViewHolder holder, int position) {
        holder.tvWinnerName.setText(list.get(position).getFirstname()+" "+list.get(position).getSurname());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvWinnerName;
        public MyViewHolder(View itemView) {
            super(itemView);
            tvWinnerName = (TextView)itemView.findViewById(R.id.tv_winner_name);
        }
    }
}
