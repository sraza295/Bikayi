package com.shahnawaz.bikayidemo.model;

import retrofit2.Call;
import retrofit2.http.GET;

public interface AllPrizeResponse {
    @GET("/v1/prize.json")
    Call<Prizes> getCountry();
}
