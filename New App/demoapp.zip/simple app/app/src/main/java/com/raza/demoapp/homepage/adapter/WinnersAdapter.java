package com.raza.demoapp.homepage.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.raza.demoapp.R;
import com.raza.demoapp.homepage.model.WinnerName;

import java.util.ArrayList;
import java.util.List;


public class WinnersAdapter extends RecyclerView.Adapter<WinnersAdapter.MyViewHolder> {
    private Context context;
    private List<WinnerName> list = new ArrayList<>();
    public WinnersAdapter(Context context, List<WinnerName> list){
        this.context = context;
        this.list = list;
    }
    @Override
    public WinnersAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.multiple_winners_card_item,parent,false);
        MyViewHolder myViewHolder = new MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(WinnersAdapter.MyViewHolder holder, int position) {
        holder.tv_full_winner_name.setText(list.get(position).getName());
        holder.tv_category.setText(list.get(position).getCategory());
        holder.tv_years.setText(list.get(position).getYears());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tv_full_winner_name;
        TextView tv_category;
        TextView tv_years;
        public MyViewHolder(View itemView) {
            super(itemView);
            tv_full_winner_name = (TextView)itemView.findViewById(R.id.tv_full_winner_name);
            tv_category = (TextView)itemView.findViewById(R.id.tv_category);
            tv_years = (TextView)itemView.findViewById(R.id.tv_years);

        }
    }
}
