package com.raza.demoapp.homepage.core;

import android.app.ProgressDialog;
import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.raza.demoapp.homepage.service.AllPrizeResponse;
import com.raza.demoapp.homepage.model.Laureate;
import com.raza.demoapp.homepage.model.Prize;
import com.raza.demoapp.homepage.model.Prizes;
import com.raza.demoapp.homepage.model.WinnerName;
import com.raza.demoapp.utility.InternetConnection;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Intractor implements GetDataContract.Interactor{
    private GetDataContract.onGetDataListener mOnGetDatalistener;
    List<Prize> allPrizes = new ArrayList<>();
    List<String> allPrizesData = new ArrayList<>();
    List<List<Laureate>> laureates = new ArrayList<List<Laureate>>();
    Set<String> allCategoryData = new HashSet<>();
    Map<String, WinnerName> mapOfMoreThanOneWineer = new HashMap<String, WinnerName>();
    public static List<WinnerName> listofwinners= new ArrayList();

    public Intractor(GetDataContract.onGetDataListener mOnGetDatalistener){
        this.mOnGetDatalistener = mOnGetDatalistener;
    }

    public Intractor() {
    }

    @Override
    public void initRetrofitCall(Context context, String url, final ProgressDialog dialog) {


        dialog.setTitle("Getting JSON data");
        dialog.setMessage("Please wait...");
        dialog.show();
        if (InternetConnection.checkConnection(context))
        {
            listofwinners.clear();
                Gson gson = new GsonBuilder()
                        .setLenient()
                        .create();
                Retrofit retrofit = new Retrofit.Builder()
                        .baseUrl("http://api.nobelprize.org")
                        .addConverterFactory(GsonConverterFactory.create(gson))
                        .build();
                AllPrizeResponse request = retrofit.create(AllPrizeResponse.class);
                retrofit2.Call<Prizes> call = request.getPrizes();

                    call.enqueue(new retrofit2.Callback<Prizes>() {
                        @Override
                        public void onResponse(retrofit2.Call<Prizes> call, retrofit2.Response<Prizes> response) {
                            dialog.dismiss();
                            Prizes jsonResponse = response.body();
                            allPrizes = jsonResponse.getPrizes();
                            for(int i=0;i<allPrizes.size();i++){
                                String category=allPrizes.get(i).getCategory();
                                String year=allPrizes.get(i).getYear();

                                List<Laureate> laureateList = allPrizes.get(i).getLaureates();
                                //System.out.println(new Gson().toJson(laureateList));
                                if (laureateList!=null)
                                {
                                    for (int j=0;j<laureateList.size();j++)
                                    {
                                        //System.out.println(laureateList.get(j).getId());
                                        String id = laureateList.get(j).getId();
                                        String firstName = laureateList.get(j).getFirstname();
                                        String surName = laureateList.get(j).getSurname();

                                        String fullName="";
                                        if (surName!=null)
                                        {
                                            fullName=firstName+" "+surName;
                                        }
                                        else
                                        {
                                            fullName=firstName;
                                        }

                                        if (mapOfMoreThanOneWineer.containsKey(id))
                                        {
                                            WinnerName winnerName = mapOfMoreThanOneWineer.get(id);
                                            winnerName.setCount(winnerName.getCount()+1);
                                            winnerName.setName(fullName);
                                            winnerName.setYears(winnerName.getYears()+", "+year);
                                            winnerName.setCategory(category);

                                            mapOfMoreThanOneWineer.put(id,winnerName);


                                        }
                                        else
                                        {
                                            WinnerName winnerName = new WinnerName(1, fullName,year,category);
                                            mapOfMoreThanOneWineer.put(id,winnerName);
                                        }

                                    }
                                }


                                allPrizesData.add(category);
                                if (!allCategoryData.contains(category))
                                {
                                    allCategoryData.add(category);
                                }
                            }
                            Log.d("Data", "Refreshed");

                            for (Map.Entry<String, WinnerName> entry : mapOfMoreThanOneWineer.entrySet())
                            {
                                //System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
                                if (entry.getValue().getCount()>1)
                                {
                                    //System.out.println("Key = " + entry.getKey() + ", Value = " + new Gson().toJson(entry.getValue()));
                                    listofwinners.add(entry.getValue());
                                }
                            }

                            //System.out.println("allPrizes "+new Gson().toJson(listofwinners));
                            mOnGetDatalistener.onSuccess("List Size: " + allPrizesData.size(), allPrizes);
                            mOnGetDatalistener.showSpinnerCategory(allCategoryData);
                            mOnGetDatalistener.showSpinnerYear(addYearInList());
                        }
                        @Override
                        public void onFailure(retrofit2.Call<Prizes> call, Throwable t) {
                            dialog.dismiss();
                            Log.v("Error",t.getMessage());
                            mOnGetDatalistener.onFailure(t.getMessage());
                        }
                    });



        }

        else {
            dialog.dismiss();
            Toast.makeText(context, "Check your internet connection!", Toast.LENGTH_SHORT).show();
        }




    }

    @Override
    public void searchDataFromList(Context context, String year, String category) {
        List<Laureate> winners=new ArrayList<>();
        String message="";
        for (int i=0;i<allPrizes.size();i++)
        {
            if (allPrizes.get(i).getCategory().equalsIgnoreCase(category) && allPrizes.get(i).getYear().equalsIgnoreCase(year))
            {
               winners = allPrizes.get(i).getLaureates();
            }
        }
        mOnGetDatalistener.showSearchedData(message,winners);
    }

    public List addYearInList() {

        List listYear = new ArrayList();
        for (int i = 1901; i <=2018; i++) {
            listYear.add(i);
        }
        return listYear;
    }
    
}
