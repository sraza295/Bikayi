
package com.raza.demoapp.homepage.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Prize {

    @SerializedName("year")
    @Expose
    private String year;
    @SerializedName("category")
    @Expose
    private String category;
    @SerializedName("laureates")
    @Expose
    private List<Laureate> laureates = null;

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public List<Laureate> getLaureates() {
        return laureates;
    }

    public void setLaureates(List<Laureate> laureates) {
        this.laureates = laureates;
    }

}
