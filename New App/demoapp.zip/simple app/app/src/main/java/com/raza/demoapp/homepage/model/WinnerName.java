package com.raza.demoapp.homepage.model;

public class WinnerName
{
    int count;
    String name;
    String years;
    String category;

    public WinnerName(int count, String name, String years, String category) {
        this.count = count;
        this.name = name;
        this.years = years;
        this.category = category;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getYears() {
        return years;
    }

    public void setYears(String years) {
        this.years = years;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
