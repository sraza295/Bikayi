package com.raza.demoapp.homepage.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.raza.demoapp.R;
import com.raza.demoapp.homepage.adapter.WinnersAdapter;
import com.raza.demoapp.homepage.core.Intractor;
import com.raza.demoapp.homepage.model.WinnerName;
import com.raza.demoapp.utility.InternetConnection;

import java.util.List;
import java.util.Map;

public class DisplayMultipleWinners extends AppCompatActivity{

    RecyclerView recyclerView;
    LinearLayoutManager linearLayoutManager;
    WinnersAdapter winnersAdapter;
    Intractor interactor = new Intractor();
    List listOfWinners = Intractor.listofwinners;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_multiple_winners);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Multiple Winners");

        if (InternetConnection.checkConnection(getApplicationContext()))
        {
            System.out.println(listOfWinners);
            recyclerView = (RecyclerView)findViewById(R.id.recycler_multiple_winners);
            linearLayoutManager = new LinearLayoutManager(this);
            recyclerView.setLayoutManager(linearLayoutManager);
            winnersAdapter = new WinnersAdapter(getApplicationContext(), listOfWinners);
            recyclerView.setAdapter(winnersAdapter);

        }
        else {
            System.out.println("check net");
            Toast.makeText(getApplicationContext(), "Check Your internet connection", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) { switch(item.getItemId()) {
        case R.id.home:
            Intent intentHome = new Intent(DisplayMultipleWinners.this, MainActivity.class);
            startActivity(intentHome);
            return(true);
        case R.id.show_multiple_winner:
            Intent intentAddContacts = new Intent(DisplayMultipleWinners.this, DisplayMultipleWinners.class);
            startActivity(intentAddContacts);
            return(true);
        case R.id.exit:
            finish();
            return(true);
    }
        return(super.onOptionsItemSelected(item));
    }

}
