package com.raza.demoapp.homepage.core;

import android.app.ProgressDialog;
import android.content.Context;

import com.raza.demoapp.homepage.model.Laureate;
import com.raza.demoapp.homepage.model.Prize;

import java.util.List;
import java.util.Set;

public interface GetDataContract {
    interface View{
        void onGetDataSuccess(String message, List<Prize> list);
        void onGetDataFailure(String message);
        void onGetDataSpinnerCategory(Set<String> list);
        void onGetDataSpinnerYear(List listYear);
        void onGetSearchedData(String message, List<Laureate> winners);


    }
    interface Presenter{
        void getDataFromURL(Context context, String url, ProgressDialog dialog);
        void searchFromList(Context context, String year, String category);

    }
    interface Interactor{
        void initRetrofitCall(Context context, String url, ProgressDialog dialog);
        void searchDataFromList(Context context, String year, String category);
    }
    interface onGetDataListener{
        void onSuccess(String message, List<Prize> list);
        void onFailure(String message);
        void showSpinnerCategory(Set<String> list);
        void showSpinnerYear(List list);
        void showSearchedData(String message, List<Laureate> winners);

    }
}
