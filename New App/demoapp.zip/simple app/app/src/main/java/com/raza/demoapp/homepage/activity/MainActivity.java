package com.raza.demoapp.homepage.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.raza.demoapp.R;
import com.raza.demoapp.homepage.adapter.PrizesAdapter;
import com.raza.demoapp.homepage.core.GetDataContract;
import com.raza.demoapp.homepage.core.Presenter;
import com.raza.demoapp.homepage.model.Laureate;
import com.raza.demoapp.homepage.model.Prize;
import com.raza.demoapp.utility.InternetConnection;

import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity implements GetDataContract.View {

    private Presenter mPresenter;
    RecyclerView recyclerView;
    LinearLayoutManager linearLayoutManager;
    PrizesAdapter prizesAdapter;

    Spinner spinnerCategory, spinnerYear;
    Button btnSearch;

    String category="";
    String year="";

    ProgressDialog dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Nobel Prize Winners");

        if (InternetConnection.checkConnection(getApplicationContext()))
        {
            spinnerCategory = (Spinner)findViewById(R.id.spinnerCategory);
            spinnerYear = (Spinner)findViewById(R.id.spinnerYear);
            btnSearch = (Button) findViewById(R.id.btnSearch);

            mPresenter = new Presenter(this);
            dialog=new ProgressDialog(MainActivity.this);
            mPresenter.getDataFromURL(getApplicationContext(), "", dialog);
            recyclerView = (RecyclerView)findViewById(R.id.recycler);
            linearLayoutManager = new LinearLayoutManager(this);
            recyclerView.setLayoutManager(linearLayoutManager);

            btnSearch.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    searchData();
                }
            });
        }
        else {
            System.out.println("check net");
            Toast.makeText(getApplicationContext(), "Check Your internet connection", Toast.LENGTH_SHORT).show();
        }


    }

    private void searchData()
    {
        //System.out.println(year+category);
        mPresenter.searchFromList(getApplicationContext(),year, category);

    }

    @Override
    public void onGetDataSuccess(String message, List<Prize> allCountriesData) {
        /*countryAdapter = new PrizesAdapter(getApplicationContext(), allCountriesData);
        recyclerView.setAdapter(countryAdapter);*/
    }

    @Override
    public void onGetDataFailure(String message) {
        Log.d("Status",message);
    }

    @Override
    public void onGetDataSpinnerCategory(Set<String> list) {

        String[] arrayCategory = new String[list.size()];
        list.toArray(arrayCategory);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,R.layout.support_simple_spinner_dropdown_item,arrayCategory);

        adapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(adapter);

        spinnerCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(parent.getSelectedItem() == "Select a category"){

                }else{
                    category=parent.getItemAtPosition(position).toString();
                    //Toast.makeText(MainActivity.this, "Selected item is "+parent.getItemAtPosition(position).toString(), Toast.LENGTH_SHORT).show();

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    public void onGetDataSpinnerYear(List listYear) {

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,R.layout.support_simple_spinner_dropdown_item,listYear);

        adapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        spinnerYear.setAdapter(adapter);

        spinnerYear.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(parent.getSelectedItem() == "Select a year"){

                }else{
                    year=parent.getItemAtPosition(position).toString();
                    //Toast.makeText(MainActivity.this, "Selected item is "+parent.getItemAtPosition(position).toString(), Toast.LENGTH_SHORT).show();

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    public void onGetSearchedData(String message, List<Laureate> winners) {
        System.out.println(new Gson().toJson(winners));
        prizesAdapter = new PrizesAdapter(getApplicationContext(), winners);
        recyclerView.setAdapter(prizesAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) { switch(item.getItemId()) {
        case R.id.home:
            Intent intentHome = new Intent(MainActivity.this, MainActivity.class);
            startActivity(intentHome);
            return(true);
        case R.id.show_multiple_winner:
            Intent intentAddContacts = new Intent(MainActivity.this, DisplayMultipleWinners.class);
            startActivity(intentAddContacts);
            return(true);
        case R.id.exit:
            finish();
            return(true);
    }
        return(super.onOptionsItemSelected(item));
    }



}
