package com.raza.demoapp.homepage.core;

import android.app.ProgressDialog;
import android.content.Context;

import com.raza.demoapp.homepage.model.Laureate;
import com.raza.demoapp.homepage.model.Prize;

import java.util.List;
import java.util.Set;

public class Presenter implements GetDataContract.Presenter, GetDataContract.onGetDataListener {
    private GetDataContract.View mGetDataView;
    private Intractor mIntractor;
    public Presenter(GetDataContract.View mGetDataView){
        this.mGetDataView = mGetDataView;
        mIntractor = new Intractor(this);
    }

    @Override
    public void getDataFromURL(Context context, String url, ProgressDialog dialog) {
        mIntractor.initRetrofitCall(context,url,dialog);
    }

    @Override
    public void searchFromList(Context context, String year, String category) {
        mIntractor.searchDataFromList(context,year,category);
    }


    @Override
    public void onSuccess(String message, List<Prize> allCountriesData) {
        mGetDataView.onGetDataSuccess(message, allCountriesData);
    }

    @Override
    public void onFailure(String message) {
        mGetDataView.onGetDataFailure(message);
    }

    @Override
    public void showSpinnerCategory(Set<String> allCategory) {
        mGetDataView.onGetDataSpinnerCategory(allCategory);
    }

    @Override
    public void showSpinnerYear(List list) {
        mGetDataView.onGetDataSpinnerYear(list);
    }

    @Override
    public void showSearchedData(String message,List<Laureate> winners) {
        mGetDataView.onGetSearchedData(message,winners);
    }


}
