package com.raza.demoapp.homepage.service;

import com.raza.demoapp.homepage.model.Prizes;

import retrofit2.Call;
import retrofit2.http.GET;

public interface AllPrizeResponse {
    @GET("/v1/prize.json")
    Call<Prizes> getPrizes();
}
